# README
**Run Driver.jar to run the driver.**

It will show the following output at first:

>Please enter the world specification file path:
> 
Then enter the filepath "res/mansion.txt"


It will show the option selection:
>Select option:  
1.Move target   
2.Output image  
3.Display rooms by index  
4.Neighbours by index  
5.Visible rooms by index  
6.Exit

